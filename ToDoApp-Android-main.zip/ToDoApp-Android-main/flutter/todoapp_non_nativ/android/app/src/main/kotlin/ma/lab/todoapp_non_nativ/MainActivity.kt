package ma.lab.todoapp_non_nativ

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

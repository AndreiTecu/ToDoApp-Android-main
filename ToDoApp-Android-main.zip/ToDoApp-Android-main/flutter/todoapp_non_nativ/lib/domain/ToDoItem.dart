
class ToDoItem{

  int id;
  String title;
  String description;
  String state;
  String deadline;
  ToDoItem(this.id,this.title,this.description,this.state,this.deadline);
}